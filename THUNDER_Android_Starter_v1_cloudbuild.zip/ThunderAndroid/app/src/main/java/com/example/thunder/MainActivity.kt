package com.example.thunder

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF101B2D)
private val Blue = Color(0xFF1976D2)
private val Red = Color(0xFFD32F2F)
private val Pale = Color(0xFFF2F5F9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ThunderApp() }
    }
}

data class Incident(
    val type: String,
    val details: String,
    val location: String,
    val time: String
)

private class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("thunder_store", Context.MODE_PRIVATE)

    fun getPhone(): String = prefs.getString("emergency_phone", "") ?: ""
    fun savePhone(phone: String) { prefs.edit().putString("emergency_phone", phone).apply() }

    fun getIncidents(): List<Incident> {
        val raw = prefs.getString("incidents", "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                Incident(
                    o.optString("type"),
                    o.optString("details"),
                    o.optString("location"),
                    o.optString("time")
                )
            }.reversed()
        } catch (_: Exception) { emptyList() }
    }

    fun addIncident(item: Incident) {
        val array = JSONArray(prefs.getString("incidents", "[]") ?: "[]")
        array.put(JSONObject().apply {
            put("type", item.type)
            put("details", item.details)
            put("location", item.location)
            put("time", item.time)
        })
        prefs.edit().putString("incidents", array.toString()).apply()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThunderApp() {
    val context = LocalContext.current
    val store = remember { LocalStore(context) }
    var selectedTab by remember { mutableStateOf("Home") }
    var emergencyPhone by remember { mutableStateOf(store.getPhone()) }
    var incidents by remember { mutableStateOf(store.getIncidents()) }
    var currentLocation by remember { mutableStateOf("Location not checked") }
    var locationBusy by remember { mutableStateOf(false) }
    var showLocationPermissionMessage by remember { mutableStateOf(false) }

    val locationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            fetchLocation(context) { currentLocation = it; locationBusy = false }
        } else {
            locationBusy = false
            showLocationPermissionMessage = true
        }
    }

    fun refreshLocation() {
        locationBusy = true
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fine || coarse) {
            fetchLocation(context) { currentLocation = it; locationBusy = false }
        } else {
            locationPermission.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            secondary = Navy,
            background = Pale,
            surface = Color.White
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("THUNDER", fontWeight = FontWeight.ExtraBold, color = Navy)
                            Text("Personal & Community Security", fontSize = 11.sp, color = Color.Gray)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Report", "History", "Contacts", "Tips").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Text(
                                when (tab) {
                                    "Home" -> "⌂"; "Report" -> "＋"; "History" -> "▤"
                                    "Contacts" -> "☎"; else -> "ⓘ"
                                },
                                fontSize = 19.sp
                            ) },
                            label = { Text(tab) }
                        )
                    }
                }
            },
            containerColor = Pale
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                when (selectedTab) {
                    "Home" -> HomeScreen(
                        location = currentLocation,
                        locationBusy = locationBusy,
                        onGetLocation = { refreshLocation() },
                        onSOS = {
                            val number = emergencyPhone.trim()
                            if (number.isBlank()) {
                                selectedTab = "Contacts"
                            } else {
                                val message = "THUNDER EMERGENCY. I may need help. My location: $currentLocation"
                                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(number)}")).apply {
                                    putExtra("sms_body", message)
                                }
                                try { context.startActivity(intent) } catch (_: Exception) {
                                    android.widget.Toast.makeText(context, "No messaging app available.", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        onReport = { selectedTab = "Report" }
                    )
                    "Report" -> ReportScreen(
                        location = currentLocation,
                        onSave = { type, details ->
                            val time = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()).format(Date())
                            store.addIncident(Incident(type, details, currentLocation, time))
                            incidents = store.getIncidents()
                            selectedTab = "History"
                        }
                    )
                    "History" -> HistoryScreen(
                        incidents = incidents,
                        onShare = { item ->
                            val reportText = """
                                THUNDER — INCIDENT REPORT
                                Incident type: ${item.type}
                                Details: ${item.details}
                                Date and time: ${item.time}
                                Location: ${item.location}

                                Note: This report was shared by the device owner. Verify information before taking action.
                            """.trimIndent()
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "THUNDER incident report — ${item.type}")
                                putExtra(Intent.EXTRA_TEXT, reportText)
                            }
                            try {
                                context.startActivity(Intent.createChooser(shareIntent, "Share incident report"))
                            } catch (_: Exception) {
                                android.widget.Toast.makeText(context, "No compatible sharing app found.", android.widget.Toast.LENGTH_LONG).show()
                            }
                        }
                    )
                    "Contacts" -> ContactsScreen(
                        phone = emergencyPhone,
                        onSave = {
                            emergencyPhone = it
                            store.savePhone(it)
                            android.widget.Toast.makeText(context, "Emergency contact saved on this phone.", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    )
                    else -> TipsScreen()
                }
            }
        }
    }

    if (showLocationPermissionMessage) {
        AlertDialog(
            onDismissRequest = { showLocationPermissionMessage = false },
            title = { Text("Location permission needed") },
            text = { Text("Allow location access to add your current coordinates to an emergency alert or incident report. You can still use other app features without it.") },
            confirmButton = {
                TextButton(onClick = { showLocationPermissionMessage = false }) { Text("OK") }
            }
        )
    }
}

private fun fetchLocation(context: Context, onResult: (String) -> Unit) {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!fine && !coarse) {
        onResult("Location permission not granted")
        return
    }
    try {
        val client = LocationServices.getFusedLocationProviderClient(context)
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { location ->
                onResult(
                    if (location != null) {
                        "https://maps.google.com/?q=${location.latitude},${location.longitude}"
                    } else {
                        "Unable to get location. Turn on GPS and try again."
                    }
                )
            }
            .addOnFailureListener { onResult("Location unavailable: ${it.localizedMessage ?: "unknown error"}") }
    } catch (e: SecurityException) {
        onResult("Location permission not granted")
    }
}

@Composable
fun HomeScreen(
    location: String,
    locationBusy: Boolean,
    onGetLocation: () -> Unit,
    onSOS: () -> Unit,
    onReport: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("YOUR SAFETY MATTERS", color = Color.White.copy(alpha = .75f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Stay alert. Stay safe.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Use the tools below when you need help.", color = Color.White.copy(alpha = .8f), fontSize = 13.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("EMERGENCY ALERT", fontWeight = FontWeight.Bold, color = Navy)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onSOS,
                    modifier = Modifier.size(170.dp),
                    shape = RoundedCornerShape(100.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Red)
                ) {
                    Text("SOS\nHELP", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 29.sp)
                }
                Spacer(Modifier.height(10.dp))
                Text("Opens your SMS app with an emergency message. Review and send it yourself.", fontSize = 11.sp, color = Color.Gray)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("MY LOCATION", fontWeight = FontWeight.Bold, color = Navy)
                Text(location, fontSize = 12.sp, color = Color.DarkGray)
                OutlinedButton(onClick = onGetLocation, modifier = Modifier.fillMaxWidth(), enabled = !locationBusy) {
                    Text(if (locationBusy) "Getting location..." else "Get current GPS location")
                }
            }
        }
        Button(onClick = onReport, modifier = Modifier.fillMaxWidth()) {
            Text("＋  Report an Incident")
        }
    }
}

@Composable
fun ReportScreen(location: String, onSave: (String, String) -> Unit) {
    var type by remember { mutableStateOf("Suspicious activity") }
    var details by remember { mutableStateOf("") }
    val types = listOf("Suspicious activity", "Theft", "Robbery", "Harassment", "Vandalism", "Other")
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("REPORT AN INCIDENT", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Reports are saved on this device only in this first version.", fontSize = 12.sp, color = Color.Gray)
        Text("Incident type", fontWeight = FontWeight.SemiBold)
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
            OutlinedTextField(
                value = type, onValueChange = {}, readOnly = true,
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                label = { Text("Choose incident type") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                types.forEach { item ->
                    DropdownMenuItem(text = { Text(item) }, onClick = { type = item; expanded = false })
                }
            }
        }
        OutlinedTextField(
            value = details, onValueChange = { details = it },
            modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
            label = { Text("Describe what happened") },
            placeholder = { Text("Include only details you know. Avoid guessing.") }
        )
        Text("Location: $location", fontSize = 11.sp, color = Color.Gray)
        Button(
            onClick = { onSave(type, details.trim()) },
            enabled = details.trim().isNotEmpty(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save incident report") }
    }
}

@Composable
fun HistoryScreen(
    incidents: List<Incident>,
    onShare: (Incident) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("INCIDENT HISTORY", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text(
            "Reports are stored on this device. Sharing is optional and requires your confirmation in the Android share menu.",
            fontSize = 12.sp,
            color = Color.Gray
        )
        if (incidents.isEmpty()) {
            Text("No reports saved yet.", color = Color.Gray)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(incidents) { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(
                            Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            Text(item.type, fontWeight = FontWeight.Bold, color = Navy)
                            Text(item.details, fontSize = 13.sp)
                            Text(item.time, fontSize = 11.sp, color = Color.Gray)
                            Text(item.location, fontSize = 11.sp, color = Blue)
                            OutlinedButton(
                                onClick = { onShare(item) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Share this report")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ContactsScreen(phone: String, onSave: (String) -> Unit) {
    var number by remember(phone) { mutableStateOf(phone) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("EMERGENCY CONTACT", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("Save one trusted contact number. The SOS button will open your SMS app addressed to this number.", fontSize = 13.sp, color = Color.Gray)
        OutlinedTextField(
            value = number,
            onValueChange = { number = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Phone number") },
            placeholder = { Text("e.g. +639XXXXXXXXX") }
        )
        Button(onClick = { onSave(number.trim()) }, modifier = Modifier.fillMaxWidth()) {
            Text("Save contact")
        }
        Text("Privacy: this number is stored locally on this device. This starter app does not upload it.", fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
fun TipsScreen() {
    val tips = listOf(
        "Stay aware of your surroundings, especially in unfamiliar places.",
        "Tell a trusted person where you are going and when you expect to return.",
        "Keep your phone charged and important emergency numbers accessible.",
        "Move to a well-lit, populated place if you feel unsafe.",
        "Do not confront a suspected offender. Prioritize your safety and contact authorities.",
        "When reporting an incident, share facts you personally observed and avoid posting private information publicly."
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("SAFETY TIPS", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tips) { tip ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Text("•  $tip", Modifier.padding(14.dp), fontSize = 14.sp)
                }
            }
        }
    }
}
