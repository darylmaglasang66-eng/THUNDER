# THUNDER — Android starter app

THUNDER is an early Kotlin + Jetpack Compose Android prototype for personal and community safety.

## Currently included (local prototype)
- Home dashboard with an SOS button
- GPS location retrieval after the user grants location permission
- SOS opens the phone SMS app with the saved trusted contact and a location message; the user reviews and sends it
- Incident reports saved to local on-device history
- Optional sharing of an individual report through the Android Sharesheet; the user chooses an app and confirms sharing
- Emergency contact number saved locally
- Basic safety tips

## Not yet implemented
- User registration and sign-in
- Cloud database, cloud backup, or automatic synchronization
- Public community feed and administrator approval dashboard
- Background/continuous live location sharing
- Automatic dispatch or integration with police, ambulance, or fire services

The online community features require a configured backend, authentication, access controls, and an authorized moderation process. They are not present in this starter project yet.

## Safety notes
- The SOS action does **not** silently send an SMS. It opens the messaging app so the user can review and press Send.
- This app does not automatically contact emergency services.
- Reports are stored only on this phone until the user explicitly shares them through another app.
- GPS can fail indoors, when location is disabled, or when the device has no usable signal.
- Do not rely on this prototype as the only way to get emergency help. Contact local emergency services directly when needed.

## Build requirements
- Android Studio (recommended) with JDK 17, or a compatible Android build environment
- Android SDK Platform 35
- Minimum Android version: Android 8.0 (API 26)
- Internet access is needed for the first Gradle dependency download

## Open in Android Studio
1. Extract this ZIP.
2. Open the `ThunderAndroid` project folder in Android Studio.
3. Allow Gradle sync to finish.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Build and test the debug APK.

## Before public release
A production service needs a secure backend, authenticated accounts, encrypted transport, server-side access controls, data retention/deletion rules, abuse prevention, a privacy policy, and security testing. Community reports should be reviewed before publication, and reporters' personal information and precise locations must not be exposed publicly.
