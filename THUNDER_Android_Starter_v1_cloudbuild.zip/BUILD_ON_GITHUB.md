# Build THUNDER from a phone using GitHub Actions

This project includes `.github/workflows/android-build.yml` for a cloud debug build.

1. Create a GitHub repository named `THUNDER-Android` in your browser.
2. Upload the contents of this ZIP to the repository root (the `ThunderAndroid` folder and `.github` folder must both be at the root).
3. Open the repository's **Actions** tab.
4. Select **THUNDER Android Build** and tap **Run workflow** (or push to the `main` branch).
5. When the run succeeds, open the run and download the `THUNDER-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install the APK on your Android phone.

This workflow produces a debug APK for testing only. It is not a signed production release and does not implement cloud accounts, public community reporting, or emergency-service dispatch.
